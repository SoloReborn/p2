//All Variables
let input = document.getElementById("inputTask");
let create = document.getElementById("create");
let tasks = document.getElementById("task");
let paragraph = document.getElementById("paragraph");
let alertBox = document.getElementById("alert")

 //Task Remaining Left
 let remain = 0;
 let counter = document.getElementById ("taskLeft");

 //Creates a New Task 
create.addEventListener('click', () => { 
    if (input.value != 0) { 
        //creates a div that takes input value
        let newItem = document.createElement("div");
        //assigns a new id to newItem
        newItem.id = 'item';
        //adds style called 'item' 
        newItem.classList.add('item');
        newItem.classList.add('fade-In');
        counter.classList.remove('hide')
        counter.classList.add('fade-In');
        newItem.innerHTML = ` 
        <p class="paragraph" id="paragraph"> ${input.value} </p>
        <div  class="item-del" id="item-del">
            <button onclick="deleteTask()">
            <i class="fa-regular fa-trash-can"></i>
            </button>
        </div>
        ` 
        //jquery learned at w3schools.com 
        
        //adds style to the div
        tasks.appendChild(newItem);
        //Displays Main Counter
        counter.innerHTML = `
        <h2> Task remaining: ${remain} </h2>
        `
        remain ++; // +1
        console.log(remain);
        //updates counter
        counter.innerHTML = `
        <h2> Task remaining: ${remain} </h2>
        `
        input.value = '';
    } else {
        //else a notification will appear top-right
        alertBox.classList.remove('hide')
        alertBox.classList.add('fade-In');
        console.log("Please add a task!")
        //timeout that automatically closes the notification after 10 seconds
        setTimeout(function() {
            alertBox.classList.add('hide')
            alertBox.classList.remove('fade-In');
            console.log("Closing notification..")
        },8000);
    }
})


//delete a task function
function deleteTask() {
    let theItem = document.getElementById("item");
    let parent = theItem.parentNode; //learned from w3schools.com 
    parent.removeChild(theItem);
    console.log("removed a task");
    remain --; // -1
    console.log(remain);
    counter.innerHTML = `
        <h2> Task remaining: ${remain} </h2>
        `
    if (remain == 0) {
        counter.innerHTML = `
        <h2> All Task Completed. Good job today!</h2>
        `
        setTimeout(function() {
            counter.classList.add('hide'); //add 'hide' for no animation
            counter.classList.remove('fade-In');
            console.log("restarting..")
        },6000); //Hides message and restarts application
    }
}

//delete notification
function deleteNo() {
    alertBox.classList.add('hide')
    console.log("Closed notification")
}
